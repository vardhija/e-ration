package com.capg.config;

public class SecurityConfig {

}
