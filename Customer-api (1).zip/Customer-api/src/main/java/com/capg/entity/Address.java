package com.capg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Address_tbl")
public class Address {
	@Id
	@Column(name = "address_pin")
	private Integer pin;
	@Column(name="address_city")
	private String city;
	@Column(name="address_state")
	private String state;
	

	
	public Address() {
		
	}



	public Address(Integer pin, String city, String state) {
		super();
		this.pin = pin;
		this.city = city;
		this.state = state;
	}



	public Integer getPin() {
		return pin;
	}



	public void setPin(Integer pin) {
		this.pin = pin;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	@Override
	public String toString() {
		return "Address [pin=" + pin + ", city=" + city + ", state=" + state + "]";
	}
	


}
